package com.lhu.billerInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillerInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
