package com.lhu.transaction.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lhu.transaction.model.Transactiondata;

public interface TransactiondataDao extends JpaRepository<Transactiondata, Integer>{

}
